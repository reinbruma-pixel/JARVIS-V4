package com.jarvis.app
import android.accessibilityservice.AccessibilityService as A
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.SmsManager
import android.os.*
import android.speech.*
import android.speech.tts.*
import org.json.*
import java.net.*
import java.text.SimpleDateFormat
import java.util.*
class JarvisService:Service(),TextToSpeech.OnInitListener{
 lateinit var tts:TextToSpeech;var sr:SpeechRecognizer?=null;val h=Handler(Looper.getMainLooper());var awake=false;var speaking=false;var torch=false;var pend:(()->Unit)?=null
 val pr get()=getSharedPreferences("jarvis",0)
 override fun onBind(i:Intent?):IBinder?=null
 override fun onStartCommand(i:Intent?,f:Int,s:Int):Int{
  val nm=getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel("j","Jarvis",NotificationManager.IMPORTANCE_LOW))
  val n=Notification.Builder(this,"j").setContentTitle("Jarvis is listening").setContentText("Say \"Jarvis\"").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
  startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
  if(!::tts.isInitialized)tts=TextToSpeech(this,this) else listen();return START_STICKY}
 override fun onInit(s:Int){tts.language=Locale.UK;tts.setPitch(0.8f);tts.setSpeechRate(0.95f)
  tts.voices?.firstOrNull{it.locale==Locale.UK&&!it.isNetworkConnectionRequired&&it.name.contains("gbd")}?.let{tts.voice=it}
  tts.setOnUtteranceProgressListener(object:UtteranceProgressListener(){override fun onStart(u:String?){}override fun onError(u:String?){}override fun onDone(u:String?){speaking=false;h.post{listen()}}})
  say("Good day, sir. Jarvis online.")}
 fun say(t:String){Bus.last=t;h.post{speaking=true;sr?.cancel();tts.speak(t,TextToSpeech.QUEUE_FLUSH,null,"u")}}
 fun listen(){if(speaking)return;sr?.destroy();val r=SpeechRecognizer.createSpeechRecognizer(this);sr=r
  r.setRecognitionListener(object:RecognitionListener{
   override fun onResults(b:Bundle?){Bus.energy=0f;handle(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?:"");again()}
   override fun onError(e:Int){again()}
   override fun onRmsChanged(v:Float){Bus.energy=maxOf(0f,v)}
   override fun onReadyForSpeech(p:Bundle?){}override fun onBeginningOfSpeech(){}override fun onBufferReceived(b:ByteArray?){}
   override fun onEndOfSpeech(){}override fun onPartialResults(b:Bundle?){}override fun onEvent(a:Int,b:Bundle?){}})
  r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true))}
 fun again(){if(!speaking)h.postDelayed({listen()},300)}
 fun mem(s:String){pr.edit().putString("log",(pr.getString("log","")+"\n"+SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(Date())+" "+s).takeLast(60000)).apply()}
 fun handle(raw:String){val t=raw.lowercase().trim();if(t.isEmpty())return;Bus.heard=t
  if(!awake&&!t.contains("jarvis"))return
  val c=(if(t.contains("jarvis"))t.substringAfter("jarvis") else t).trim()
  if(c.isEmpty()){awake=true;say("Yes, sir?");return};awake=false;mem("Command: $c");run(c)}
 fun acc(a:Int,m:String){val s=JarvisAccess.inst;if(s==null)say("Please enable phone control in my app first, sir.") else{s.performGlobalAction(a);say(m)}}
 fun run(c:String){if(pend!=null){val f=pend;pend=null;if("yes" in c||"confirm" in c||"send" in c)f!!() else say("Cancelled, sir.");return};when{
  c.startsWith("call ")->callName(c.removePrefix("call ").trim())
  c.startsWith("text ")||c.startsWith("message ")||c.startsWith("sms ")->sms(c)
  "good morning" in c->{val bat=getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);val n=pr.getString("notifs","")!!.lines().count{it.contains("|")}
   say("Good morning, sir. It is "+SimpleDateFormat("h:mm a, EEEE d MMMM",Locale.UK).format(Date())+". Battery is at $bat percent. You have $n recent notifications.")}
  "read" in c&&("notification" in c||"message" in c||"email" in c)->readNotifs()
  "my work" in c||"my files" in c->work()
  "time" in c->say("It is "+SimpleDateFormat("h:mm a",Locale.US).format(Date())+", sir.")
  "date" in c||"today" in c->say(SimpleDateFormat("EEEE, d MMMM",Locale.UK).format(Date()))
  "battery" in c->say("Battery is at "+(getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))+" percent.")
  c.startsWith("open ")->openApp(c.removePrefix("open ").trim())
  "flashlight" in c||"torch" in c->{torch="off" !in c;val cm=getSystemService(CameraManager::class.java);cm.setTorchMode(cm.cameraIdList[0],torch);say("Torch "+(if(torch)"on" else "off")+", sir.")}
  "volume up" in c->{getSystemService(AudioManager::class.java).adjustStreamVolume(3,1,1);say("Louder.")}
  "volume down" in c->{getSystemService(AudioManager::class.java).adjustStreamVolume(3,-1,1);say("Quieter.")}
  "home" in c->acc(A.GLOBAL_ACTION_HOME,"Home screen.")
  "back" in c->acc(A.GLOBAL_ACTION_BACK,"Going back.")
  "recent" in c->acc(A.GLOBAL_ACTION_RECENTS,"Recent apps.")
  "notification" in c->acc(A.GLOBAL_ACTION_NOTIFICATIONS,"Notifications.")
  "screenshot" in c->acc(A.GLOBAL_ACTION_TAKE_SCREENSHOT,"Screenshot taken.")
  "lock" in c->acc(A.GLOBAL_ACTION_LOCK_SCREEN,"Locking.")
  c.startsWith("remember")->{mem("NOTE: "+c.removePrefix("remember").removePrefix(" that").trim());say("Noted, sir.")}
  "my notes" in c->{val n=pr.getString("log","")!!.lines().filter{"NOTE:" in it}.takeLast(5).joinToString(". "){it.substringAfter("NOTE:")};say(if(n.isEmpty())"You have no notes, sir." else n)}
  "yesterday" in c->{val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(System.currentTimeMillis()-86400000))
   val l=pr.getString("log","")!!.lines().filter{it.startsWith(d)}.takeLast(8).joinToString(". "){it.substring(17)};say(if(l.isEmpty())"I have no record of yesterday, sir." else "Yesterday: $l")}
  else->ai(c)}}
 fun openApp(n:String){val pm=packageManager
  val a=pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0).firstOrNull{it.loadLabel(pm).toString().lowercase().contains(n)}
  if(a==null){say("I cannot find $n, sir.");return}
  val i=pm.getLaunchIntentForPackage(a.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);(JarvisAccess.inst?:this).startActivity(i);say("Opening $n.")}
 fun post(u:String,h:Map<String,String>,b:String):String{val c=URL(u).openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.connectTimeout=15000;c.readTimeout=30000
  c.setRequestProperty("content-type","application/json");h.forEach{(k,v)->c.setRequestProperty(k,v)};c.outputStream.write(b.toByteArray());return c.inputStream.bufferedReader().readText()}
 fun ask(p:String,k:String,sys:String,q:String):String{
  val msgs=JSONArray().put(JSONObject().put("role","system").put("content",sys)).put(JSONObject().put("role","user").put("content",q))
  return when(p){
   "gemini"->JSONObject(post("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$k",mapOf(),JSONObject().put("contents",JSONArray().put(JSONObject().put("parts",JSONArray().put(JSONObject().put("text",sys+"\n\n"+q))))).toString())).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
   "anthropic"->JSONObject(post("https://api.anthropic.com/v1/messages",mapOf("x-api-key" to k,"anthropic-version" to "2023-06-01"),JSONObject().put("model","claude-sonnet-5-5").put("max_tokens",300).put("system",sys).put("messages",JSONArray().put(JSONObject().put("role","user").put("content",q))).toString())).getJSONArray("content").getJSONObject(0).getString("text")
   else->{val u=if(p=="groq")"https://api.groq.com/openai/v1/chat/completions" else "https://openrouter.ai/api/v1/chat/completions"
    val m=if(p=="groq")"llama-3.3-70b-versatile" else "meta-llama/llama-3.3-70b-instruct:free"
    JSONObject(post(u,mapOf("Authorization" to "Bearer $k"),JSONObject().put("model",m).put("max_tokens",400).put("messages",msgs).toString())).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")}}}
 fun ai(q:String){val ps=listOf("gemini","groq","openrouter","anthropic").filter{pr.getString("key_$it","")!!.isNotBlank()}
  val on=getSystemService(ConnectivityManager::class.java).activeNetwork!=null
  if(ps.isEmpty()||!on){say("I am afraid I cannot answer that offline, sir.");return}
  Thread{val sys="You are JARVIS, a witty British butler AI. Reply in at most three short spoken sentences, no markdown. User's recent activity log:\n"+pr.getString("log","")!!.lines().takeLast(15).joinToString("\n")
   for(p in ps){try{val a=ask(p,pr.getString("key_$p","")!!,sys,q);mem("Jarvis: $a");say(a);return@Thread}catch(e:Exception){}}
   say("All my AI connections failed, sir.")}.start()}
 fun find(n:String):Pair<String,String>?{contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,arrayOf("display_name","data1"),"display_name LIKE ?",arrayOf("%$n%"),null)?.use{if(it.moveToFirst())return it.getString(0) to it.getString(1)};return null}
 fun callName(n:String){val r=find(n)?:run{say("I cannot find $n in your contacts, sir.");return};say("Calling ${r.first}.");getSystemService(TelecomManager::class.java).placeCall(Uri.parse("tel:"+Uri.encode(r.second)),null)}
 fun sms(c:String){val m=Regex("^(?:text|message|sms) (.+?) (?:saying|that says|say) (.+)").find(c)?:run{say("Say: text, a name, saying, then your message.");return}
  val r=find(m.groupValues[1])?:run{say("I cannot find that contact, sir.");return};val body=m.groupValues[2]
  say("Message to ${r.first}: $body. Say confirm to send.");pend={val sm=getSystemService(SmsManager::class.java);sm.sendMultipartTextMessage(r.second,null,sm.divideMessage(body),null,null);say("Sent, sir.")};awake=true}
 fun readNotifs(){val n=pr.getString("notifs","")!!.lines().filter{it.contains("|")}.takeLast(5)
  say(if(n.isEmpty())"No notifications, sir." else "You have ${n.size} recent. "+n.joinToString(". "){it.substringAfter("|")})}
 fun workText():String{val u=Uri.parse(pr.getString("tree","")?:return "");val ch=DocumentsContract.buildChildDocumentsUriUsingTree(u,DocumentsContract.getTreeDocumentId(u));val sb=StringBuilder()
  contentResolver.query(ch,arrayOf("document_id","_display_name","mime_type"),null,null,null)?.use{c->while(c.moveToNext()&&sb.length<6000){val n=c.getString(1)
   if(c.getString(2).startsWith("text/")||n.endsWith(".md")||n.endsWith(".csv")){sb.append("FILE $n:\n").append(contentResolver.openInputStream(DocumentsContract.buildDocumentUriUsingTree(u,c.getString(0)))?.bufferedReader()?.readText()?.take(1500)).append("\n")}}}
  return sb.toString()}
 fun work(){Thread{val t=try{workText()}catch(e:Exception){""};if(t.isBlank())say("I found no readable text files in your work folder, sir.") else ai("Summarise my work files in three sentences:\n"+t)}.start()}
 override fun onDestroy(){sr?.destroy();tts.shutdown();super.onDestroy()}
}
