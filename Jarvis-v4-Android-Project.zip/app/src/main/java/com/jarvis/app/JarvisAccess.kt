package com.jarvis.app
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
class JarvisAccess:AccessibilityService(){
 companion object{var inst:JarvisAccess?=null}
 override fun onServiceConnected(){inst=this}
 override fun onUnbind(i:android.content.Intent?):Boolean{inst=null;return super.onUnbind(i)}
 override fun onAccessibilityEvent(e:AccessibilityEvent?){}
 override fun onInterrupt(){}
}
