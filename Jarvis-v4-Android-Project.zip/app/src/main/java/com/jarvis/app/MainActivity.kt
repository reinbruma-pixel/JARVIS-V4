package com.jarvis.app
import android.Manifest
import android.app.*
import android.content.*
import android.graphics.*
import android.net.ConnectivityManager
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
class MainActivity:Activity(){
 lateinit var L:TextView;lateinit var R:TextView;lateinit var B:TextView;val h=Handler(Looper.getMainLooper())
 fun tv(s:Float=11f)=TextView(this).apply{setTextColor(Color.rgb(0,229,255));textSize=s;typeface=Typeface.MONOSPACE;setPadding(8,8,8,8)}
 fun btn(t:String,f:()->Unit)=Button(this).apply{text=t;textSize=10f;setTextColor(Color.rgb(0,229,255));setBackgroundColor(Color.argb(60,0,229,255));setOnClickListener{f()}}
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.BLACK);setPadding(12,60,12,12)}
  root.addView(tv(18f).apply{text="J.A.R.V.I.S";gravity=Gravity.CENTER})
  val row=LinearLayout(this);L=tv(10f);R=tv(10f)
  row.addView(L,LinearLayout.LayoutParams(0,-1,1f));row.addView(CoreView(this),LinearLayout.LayoutParams(0,-1,2.2f));row.addView(R,LinearLayout.LayoutParams(0,-1,1f))
  root.addView(row,LinearLayout.LayoutParams(-1,0,1f))
  B=tv(11f);root.addView(B,LinearLayout.LayoutParams(-1,-2))
  val ps=arrayOf("gemini","groq","openrouter","anthropic");val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,ps)
  val key=EditText(this).apply{hint="Paste free API key for the selected AI";setHintTextColor(Color.GRAY);setTextColor(Color.WHITE);textSize=11f}
  sp.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onItemSelected(a:AdapterView<*>?,v:android.view.View?,i:Int,l:Long){key.setText(getSharedPreferences("jarvis",0).getString("key_"+ps[i],""))};override fun onNothingSelected(a:AdapterView<*>?){}}
  root.addView(sp);root.addView(key)
  val br=LinearLayout(this)
  br.addView(btn("SAVE KEY"){getSharedPreferences("jarvis",0).edit().putString("key_"+sp.selectedItem,key.text.toString().trim()).apply()},LinearLayout.LayoutParams(0,-2,1f))
  br.addView(btn("ALLOW PHONE CONTROL"){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))},LinearLayout.LayoutParams(0,-2,1.4f))
  br.addView(btn("BATTERY: ALLOW"){startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))},LinearLayout.LayoutParams(0,-2,1.2f))
  root.addView(br)
  val b2=LinearLayout(this)
  b2.addView(btn("ALLOW NOTIFICATIONS / EMAIL ALERTS"){startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))},LinearLayout.LayoutParams(0,-2,1f))
  b2.addView(btn("CHOOSE WORK FOLDER"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(1 or 64),7)},LinearLayout.LayoutParams(0,-2,1f))
  root.addView(b2);setContentView(root)
  requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO,Manifest.permission.POST_NOTIFICATIONS,Manifest.permission.READ_CONTACTS,Manifest.permission.CALL_PHONE,Manifest.permission.SEND_SMS),1)}
 override fun onRequestPermissionsResult(c:Int,p:Array<out String>,g:IntArray){startForegroundService(Intent(this,JarvisService::class.java))}
override fun onActivityResult(r:Int,s:Int,d:Intent?){super.onActivityResult(r,s,d);d?.data?.let{contentResolver.takePersistableUriPermission(it,1);getSharedPreferences("jarvis",0).edit().putString("tree",it.toString()).apply()}}
 override fun onResume(){super.onResume();h.post(object:Runnable{override fun run(){refresh();h.postDelayed(this,700)}})}
 override fun onPause(){super.onPause();h.removeCallbacksAndMessages(null)}
 fun refresh(){
  val bi=registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED));val bat=bi!!.getIntExtra("level",0)*100/bi.getIntExtra("scale",100)
  val mi=ActivityManager.MemoryInfo();(getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
  val sf=StatFs(Environment.getDataDirectory().path);val net=(getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).activeNetwork!=null
  L.text="SYSTEM\nTIME\n"+SimpleDateFormat("HH:mm:ss").format(Date())+"\n\nBATTERY\n$bat%\n\nRAM FREE\n${mi.availMem/1048576} MB\n\nSTORAGE FREE\n${sf.availableBytes/1073741824} GB"
  val mem=getSharedPreferences("jarvis",0).getString("log","")!!.lines().filter{it.isNotBlank()}.takeLast(4).joinToString("\n"){it.substringAfter(' ').take(28)}
  R.text="NETWORK\n"+(if(net)"ONLINE" else "OFFLINE")+"\n\nMODE\n${Bus.status}\n\nHEARD\n${Bus.heard.take(30)}\n\nMEMORY\n$mem"
  B.text="> "+Bus.last;Bus.status=if(net&&getSharedPreferences("jarvis",0).all.keys.any{it.startsWith("key_")&&!getSharedPreferences("jarvis",0).getString(it,"").isNullOrBlank()})"AI + LOCAL" else "LOCAL BRAIN"}
}
