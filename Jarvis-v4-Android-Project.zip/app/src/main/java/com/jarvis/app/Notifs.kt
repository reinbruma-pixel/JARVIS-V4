package com.jarvis.app
import android.service.notification.*
class Notifs:NotificationListenerService(){
 override fun onNotificationPosted(s:StatusBarNotification){val e=s.notification.extras;val t=e.getCharSequence("android.title")?:return;val x=e.getCharSequence("android.text")?:""
  if(s.packageName==packageName||s.isOngoing)return;val p=getSharedPreferences("jarvis",0)
  p.edit().putString("notifs",(p.getString("notifs","")+"\n"+s.packageName+"|"+s.packageName.substringAfterLast('.')+": "+t+", "+x).replace("\r"," ").takeLast(8000)).apply()}
}
