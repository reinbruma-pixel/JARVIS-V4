package com.jarvis.app
import android.content.*
class Boot:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){try{c.startForegroundService(Intent(c,JarvisService::class.java))}catch(e:Exception){}}}
