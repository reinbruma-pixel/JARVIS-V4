package com.jarvis.app
object Bus{@Volatile var energy=0f;@Volatile var heard="-";@Volatile var last="Standing by, sir.";@Volatile var status="OFFLINE MODE"}
