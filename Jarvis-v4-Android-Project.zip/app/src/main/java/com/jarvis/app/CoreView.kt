package com.jarvis.app
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.*
class CoreView(c:Context):View(c){
 private val p=Paint(Paint.ANTI_ALIAS_FLAG); private var t=0f; private val cy=Color.rgb(0,229,255)
 init{ValueAnimator.ofFloat(0f,360f).apply{duration=9000;repeatCount=-1;interpolator=LinearInterpolator();addUpdateListener{t=it.animatedValue as Float;invalidate()}}.start()}
 override fun onDraw(c:Canvas){
  val x=width/2f;val y=height/2f;val r=min(width,height)/2f*0.95f
  val pulse=1f+0.05f*sin(Math.toRadians(t*8.0)).toFloat()+Bus.energy*0.012f
  p.style=Paint.Style.FILL;p.shader=RadialGradient(x,y,r*0.55f*pulse,Color.argb(170,0,229,255),Color.TRANSPARENT,Shader.TileMode.CLAMP)
  c.drawCircle(x,y,r*0.55f*pulse,p);p.shader=null;p.style=Paint.Style.STROKE
  for(i in 0..4){val rad=r*(0.38f+0.12f*i);c.save();c.rotate(t*(if(i%2==0)1f else -1f)*(1+i*0.6f),x,y)
   p.color=Color.argb(210-i*30,0,229,255);p.strokeWidth=2f+i%2*3f;p.pathEffect=DashPathEffect(floatArrayOf(14f+i*18f,8f+i*4f),0f)
   c.drawCircle(x,y,rad,p);c.restore()}
  p.pathEffect=null;p.strokeWidth=5f;p.color=Color.WHITE
  c.save();c.rotate(-t*3,x,y);c.drawArc(x-r*0.3f,y-r*0.3f,x+r*0.3f,y+r*0.3f,0f,70f,false,p);c.drawArc(x-r*0.3f,y-r*0.3f,x+r*0.3f,y+r*0.3f,180f,70f,false,p);c.restore()
  p.strokeWidth=1.5f;p.color=Color.argb(230,150,255,255);val s=r*0.24f*pulse
  c.drawCircle(x,y,s,p)
  for(k in 1..5){c.save();c.rotate(t*2+k*36f,x,y);c.drawOval(x-s*cos(k*0.3f),y-s,x+s*cos(k*0.3f),y+s,p);c.restore()}
  for(k in -3..3){val yy=y+s*k/4f;val w=sqrt(max(0f,s*s-(yy-y)*(yy-y)));c.drawLine(x-w,yy,x+w,yy,p)}
 }
}
